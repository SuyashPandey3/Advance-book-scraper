choice = input('''
#                1. Do you want to perfrom pandas quaries
#                2. Do you want to perfrom matplotlib quaries''')